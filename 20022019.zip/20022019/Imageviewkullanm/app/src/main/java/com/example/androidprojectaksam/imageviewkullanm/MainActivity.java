package com.example.androidprojectaksam.imageviewkullanm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btnaudi, btnbmw,btnmercedes,btnrenault;
    ImageView ivResim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnaudi=findViewById(R.id.btnaudi);
        btnbmw=findViewById(R.id.btnbmw);
        btnmercedes=findViewById(R.id.btnmercedes);
        btnrenault=findViewById(R.id.btnrenault);
        ivResim=findViewById(R.id.ivresim);

        btnaudi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivResim.setImageResource(R.drawable.audi);

            }
        });

        btnbmw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ivResim.setImageResource(R.drawable.bmv);
            }

        });
        btnrenault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ivResim.setImageResource(R.drawable.renault);
            }
        });
        btnmercedes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivResim.setImageResource(R.drawable.mercedes);

            }
        });


    }
}
