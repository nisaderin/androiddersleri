package com.example.androidprojectaksam.stringbirlestirme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etAd,etSoyad;
    Button btn;
    TextView tv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //findViewById() activitydeki bir nesnenin bir kod kısmına bağlanmasını sağlar.
        etAd =findViewById(R.id.etAd);
        etSoyad =findViewById(R.id.etsoyad);
        btn = findViewById(R.id.btnBirlestir);
        tv =findViewById(R.id.tvsonuc);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //getText().toString() var olan yazıyı alır
                String ad =etAd.getText().toString();
                String soyad=etSoyad.getText().toString();
                //tv yazıyı değiştirir.
                tv.setText(ad+" "+soyad);
            }
        });
    }
}
