package com.example.androidprojectaksam.hesaplamaornegi;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {

    EditText sayi1 , sayi2;
    Button btntopla,btncikar,btncarp,btnbol;
    TextView tvsonuc;

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        int butonId=v.getId();
        int sonuc =0 ;
        int say1=Integer.parseInt(sayi1.getText().toString());
        int say2=Integer.parseInt(sayi2.getText().toString());

        switch (butonId) {
            case R.id.btncarp:
                sonuc=say1*say2;
                break;

            case R.id.btnbol:
                sonuc=say1/say2;
                break;
            case R.id.btncikar:
                sonuc=say1-say2;
                break;
            case R.id.btntopla:
                sonuc=say1+say2;
                break;


        }
            tvsonuc.setText(Integer.toString(sonuc));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sayi1=findViewById(R.id.etsayi1);
        sayi2=findViewById(R.id.etsayi2);
        tvsonuc=findViewById(R.id.tvsonuc);
        btntopla=findViewById(R.id.btntopla);
        btncikar=findViewById(R.id.btncikar);
        btncarp=findViewById(R.id.btncarp);
        btnbol=findViewById(R.id.btnbol);

        btnbol.setOnClickListener(this);
        btncarp.setOnClickListener(this);
        btncikar.setOnClickListener(this);
        btntopla.setOnClickListener(this);
    }


}
