package com.example.lab08.autocompletetextview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
        MultiAutoCompleteTextView mactv;

        String[] sehirler={"kars","kastamonu","istanbul","iskenderun","muğla","muş","sivas","sinop"};
        ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actv=findViewById(R.id.autoCompleteTextView);
        mactv=findViewById(R.id.multiAutoCompleteTextView);
        adapter=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_item,sehirler);
        actv.setAdapter(adapter);
//adapter abağlayarak,string[] içerisindeki değerleri ilgili nesnede gösterdik.

             actv.setThreshold(2);
              mactv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        //MultiAutoCompleteTextView çalışması için gereklidir
         mactv.setAdapter(adapter);

        //
    }
}
