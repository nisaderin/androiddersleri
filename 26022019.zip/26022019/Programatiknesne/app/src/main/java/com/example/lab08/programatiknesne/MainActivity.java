package com.example.lab08.programatiknesne;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayout;
    Spinner spinner;
    String[] urunler={"cep telefonu","tablet","masaüstü bilgisayar","dizüstübilgisayar","smart tv"};
    ArrayAdapter<String> adapter;

    public void nesneEkle(String metin){
        //programatik nesne üretimi
        TextView tv= new TextView(getApplicationContext());
        tv.setText(metin);
        linearLayout.addView(tv);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        spinner=findViewById(R.id.spinner);
        linearLayout =findViewById(R.id.linearLayout);

        adapter=new ArrayAdapter<>(getApplication(),android.R.layout.simple_spinner_item,urunler);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(),urunler[position],Toast.LENGTH_LONG).show();
                nesneEkle(urunler[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
