package com.example.lab08.listview_arrayadapter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayAdapter<String> adapter;
    String[] dizi ={"istanbul","ankara","bodrum","tekirdağ"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter =new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1 , dizi);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Toast.makeText(getApplicationContext(), ":Tıklanan değer:"+dizi[position],Toast.LENGTH_SHORT).show();
                //bir sayfadan farklı bir sayfaya geçilmesi
                Intent intent = new Intent(MainActivity.this,Sayfa2activitiy.class);
                //diğer sayfaya veri taşıma
                intent.putExtra("sehir" ,dizi [position]);
                //bulunduğum sayfadan,diğer sayfayı açar.
                startActivity(intent);
            }
        });
    }
}
