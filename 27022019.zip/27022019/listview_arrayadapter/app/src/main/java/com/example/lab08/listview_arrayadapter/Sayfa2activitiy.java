package com.example.lab08.listview_arrayadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Sayfa2activitiy extends AppCompatActivity {

    TextView textView;
            @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2activitiy);
        //bir önceki sayfadan gelen değeri yakalamak
                String sehir = getIntent().getStringExtra("sehir");
        textView = findViewById(R.id.textView);
        textView.setText(sehir);
    }
}
